const { pool } = require('../config/db');

// Get all movies
exports.getMovies = async (req, res) => {
    try {
        const [movies] = await pool.execute(
            'SELECT * FROM movies ORDER BY created_at DESC'
        );

        res.json({
            success: true,
            count: movies.length,
            data: movies
        });
    } catch (error) {
        console.error('Error getting movies:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
};

// Get single movie
exports.getMovie = async (req, res) => {
    try {
        const [movie] = await pool.execute(
            'SELECT * FROM movies WHERE id = ?',
            [req.params.id]
        );

        if (!movie.length) {
            return res.status(404).json({
                success: false,
                error: 'Movie not found'
            });
        }

        res.json({
            success: true,
            data: movie[0]
        });
    } catch (error) {
        console.error('Error getting movie:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
};

// Create movie
exports.createMovie = async (req, res) => {
    try {
        const { title, description, release_year, duration, poster_url, trailer_url } = req.body;

        // Validate required fields
        if (!title || !description || !release_year) {
            return res.status(400).json({
                success: false,
                error: 'Please provide title, description and release year'
            });
        }

        const [result] = await pool.execute(
            'INSERT INTO movies (title, description, release_year, duration, poster_url, trailer_url) VALUES (?, ?, ?, ?, ?, ?)',
            [title, description, release_year, duration || null, poster_url || null, trailer_url || null]
        );

        const [movie] = await pool.execute(
            'SELECT * FROM movies WHERE id = ?',
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            data: movie[0]
        });
    } catch (error) {
        console.error('Error creating movie:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
};

// Update movie
exports.updateMovie = async (req, res) => {
    try {
        const { title, description, release_year, duration, poster_url, trailer_url } = req.body;

        // Check if movie exists
        const [movie] = await pool.execute(
            'SELECT * FROM movies WHERE id = ?',
            [req.params.id]
        );

        if (!movie.length) {
            return res.status(404).json({
                success: false,
                error: 'Movie not found'
            });
        }

        // Update movie
        await pool.execute(
            'UPDATE movies SET title = ?, description = ?, release_year = ?, duration = ?, poster_url = ?, trailer_url = ? WHERE id = ?',
            [
                title || movie[0].title,
                description || movie[0].description,
                release_year || movie[0].release_year,
                duration || movie[0].duration,
                poster_url || movie[0].poster_url,
                trailer_url || movie[0].trailer_url,
                req.params.id
            ]
        );

        const [updatedMovie] = await pool.execute(
            'SELECT * FROM movies WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            data: updatedMovie[0]
        });
    } catch (error) {
        console.error('Error updating movie:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
};

// Delete movie
exports.deleteMovie = async (req, res) => {
    try {
        const [movie] = await pool.execute(
            'SELECT * FROM movies WHERE id = ?',
            [req.params.id]
        );

        if (!movie.length) {
            return res.status(404).json({
                success: false,
                error: 'Movie not found'
            });
        }

        await pool.execute(
            'DELETE FROM movies WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            data: {}
        });
    } catch (error) {
        console.error('Error deleting movie:', error);
        res.status(500).json({
            success: false,
            error: 'Server error'
        });
    }
}; 