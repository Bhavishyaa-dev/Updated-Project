const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/auth');
const validateRequest = require('../middlewares/validateRequest');
const {
    registerValidator,
    loginValidator,
    updateProfileValidator
} = require('../validators/userValidator');
const {
    register,
    login,
    getProfile,
    updateProfile
} = require('../controllers/userController');

// Auth routes
router.post('/register', registerValidator, validateRequest, register);
router.post('/login', loginValidator, validateRequest, login);

// Profile routes
router.get('/profile', protect, getProfile);
router.put('/profile', protect, updateProfileValidator, validateRequest, updateProfile);

module.exports = router; 