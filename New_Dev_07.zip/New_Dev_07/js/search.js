// DOM Elements
const searchIcon = document.querySelector('.fa-magnifying-glass');
const searchModal = document.querySelector('.search-modal');
const searchInput = document.querySelector('.search-input');
const closeSearch = document.querySelector('.close-search');
const searchResults = document.querySelector('.search-results');

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    initializeSearch();
});

function initializeSearch() {
    if (!searchIcon || !searchModal || !searchInput || !closeSearch || !searchResults) {
        console.error('Search elements not found');
        return;
    }

    // Open search modal
    searchIcon.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openSearchModal();
    });

    // Close search modal
    closeSearch.addEventListener('click', (e) => {
        e.preventDefault();
        closeSearchModal();
    });

    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === searchModal) {
            closeSearchModal();
        }
    });

    // Prevent modal close when clicking inside search container
    const searchContainer = document.querySelector('.search-container');
    if (searchContainer) {
        searchContainer.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }

    // Search functionality with debounce
    searchInput.addEventListener('input', debounce(handleSearch, 300));

    // Handle escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && searchModal.style.display === 'flex') {
            closeSearchModal();
        }
    });
}

// Functions
function openSearchModal() {
    try {
        searchModal.style.display = 'flex';
        searchInput.value = '';
        searchResults.innerHTML = '';
        searchInput.focus();
    } catch (error) {
        console.error('Error opening search modal:', error);
    }
}

function closeSearchModal() {
    try {
        searchModal.style.display = 'none';
        searchInput.value = '';
        searchResults.innerHTML = '';
    } catch (error) {
        console.error('Error closing search modal:', error);
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function getUniqueMovieCards() {
    try {
        // Get all movie containers, including those that might be dynamically added
        const movieContainers = document.querySelectorAll('.movies-card, .slider-container .owl-container, .owl-carousel');
        const uniqueCards = new Map();

        movieContainers.forEach(container => {
            if (!container) return;
            
            // Get all cards within the container
            const cards = container.querySelectorAll('.cards');
            
            cards.forEach(card => {
                if (!card) return;
                
                try {
                    const title = card.querySelector('h3')?.textContent?.trim() || 
                                card.querySelector('.img-title h3')?.textContent?.trim();
                                
                    if (title && !uniqueCards.has(title.toLowerCase())) {
                        uniqueCards.set(title.toLowerCase(), card);
                    }
                } catch (err) {
                    console.error('Error processing card:', err);
                }
            });
        });

        return Array.from(uniqueCards.values());
    } catch (error) {
        console.error('Error getting unique movie cards:', error);
        return [];
    }
}

function handleSearch() {
    try {
        const searchTerm = searchInput.value.toLowerCase().trim();
        
        if (searchTerm === '') {
            searchResults.innerHTML = '';
            return;
        }

        const allUniqueCards = getUniqueMovieCards();
        console.log('Found cards:', allUniqueCards.length); // Debug log
        
        const results = allUniqueCards.filter(card => {
            try {
                const title = card.querySelector('h3')?.textContent?.toLowerCase().trim() || 
                            card.querySelector('.img-title h3')?.textContent?.toLowerCase().trim() || '';
                const genre = card.querySelector('p')?.textContent?.toLowerCase().trim() || 
                            card.querySelector('span')?.textContent?.toLowerCase().trim() || '';
                
                return title.includes(searchTerm) || genre.includes(searchTerm);
            } catch (error) {
                console.error('Error filtering card:', error);
                return false;
            }
        });

        console.log('Search results:', results.length); // Debug log
        displayResults(results, searchTerm);
    } catch (error) {
        console.error('Error in handleSearch:', error);
        displayError();
    }
}

function displayResults(results, searchTerm) {
    try {
        searchResults.innerHTML = '';
        
        if (results.length === 0) {
            displayNoResults(searchTerm);
            return;
        }

        const resultsContainer = document.createElement('div');
        resultsContainer.className = 'search-results-grid';

        // Add results count
        const resultsCount = document.createElement('div');
        resultsCount.className = 'results-count';
        resultsCount.textContent = `Found ${results.length} result${results.length !== 1 ? 's' : ''}`;
        searchResults.appendChild(resultsCount);

        results.forEach(result => {
            try {
                // Create a new card instead of cloning to avoid event listener issues
                const newCard = document.createElement('div');
                newCard.className = 'cards search-result-item';
                
                // Get the video URLs from the original buttons
                const watchNowBtn = result.querySelector('.btn-1');
                const trailerBtn = result.querySelector('.btn-2');
                const watchNowUrl = watchNowBtn ? watchNowBtn.getAttribute('onclick') : '';
                const trailerUrl = trailerBtn ? trailerBtn.getAttribute('onclick') : '';

                // Extract video IDs from onclick attributes if they exist
                const watchNowId = extractVideoId(watchNowUrl);
                const trailerId = extractVideoId(trailerUrl);

                // Copy the inner HTML from the original card
                newCard.innerHTML = result.innerHTML;

                // Find the buttons in the new card
                const newWatchNowBtn = newCard.querySelector('.btn-1');
                const newTrailerBtn = newCard.querySelector('.btn-2');

                // Add click handlers for the buttons
                if (newWatchNowBtn && watchNowId) {
                    newWatchNowBtn.onclick = null; // Remove any existing onclick
                    newWatchNowBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        handleWatchNow(watchNowId);
                    });
                }

                if (newTrailerBtn && trailerId) {
                    newTrailerBtn.onclick = null; // Remove any existing onclick
                    newTrailerBtn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        handleTrailer(trailerId);
                    });
                }

                // Add click event to the card (excluding buttons)
                newCard.addEventListener('click', (e) => {
                    if (e.target.classList.contains('btn-1') || e.target.classList.contains('btn-2')) {
                        return;
                    }
                    closeSearchModal();
                });

                resultsContainer.appendChild(newCard);
            } catch (error) {
                console.error('Error creating result card:', error);
            }
        });

        searchResults.appendChild(resultsContainer);
    } catch (error) {
        console.error('Error displaying results:', error);
        displayError();
    }
}

function extractVideoId(onclickAttr) {
    try {
        if (!onclickAttr) return null;
        
        // Try to extract video ID from different onclick patterns
        // Pattern 1: playVideo('videoId')
        const playVideoMatch = onclickAttr.match(/playVideo\(['"]([^'"]+)['"]\)/);
        if (playVideoMatch) return playVideoMatch[1];

        // Pattern 2: watchTrailer('videoId')
        const watchTrailerMatch = onclickAttr.match(/watchTrailer\(['"]([^'"]+)['"]\)/);
        if (watchTrailerMatch) return watchTrailerMatch[1];

        // Pattern 3: Direct YouTube URL
        const youtubeMatch = onclickAttr.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\s]+)/);
        if (youtubeMatch) return youtubeMatch[1];

        return null;
    } catch (error) {
        console.error('Error extracting video ID:', error);
        return null;
    }
}

function handleWatchNow(videoId) {
    try {
        if (!videoId) {
            console.error('No video ID provided for Watch Now');
            return;
        }

        // Create or get the video modal
        let videoModal = document.getElementById('videoModal');
        if (!videoModal) {
            videoModal = createVideoModal();
        }

        const videoContainer = videoModal.querySelector('.video-container');
        videoContainer.innerHTML = `
            <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen
            ></iframe>
        `;

        videoModal.style.display = 'flex';
    } catch (error) {
        console.error('Error in handleWatchNow:', error);
    }
}

function handleTrailer(videoId) {
    try {
        if (!videoId) {
            console.error('No video ID provided for trailer');
            return;
        }

        // Create or get the video modal
        let videoModal = document.getElementById('videoModal');
        if (!videoModal) {
            videoModal = createVideoModal();
        }

        const videoContainer = videoModal.querySelector('.video-container');
        videoContainer.innerHTML = `
            <iframe
                width="100%"
                height="100%"
                src="https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowfullscreen
            ></iframe>
        `;

        videoModal.style.display = 'flex';
    } catch (error) {
        console.error('Error in handleTrailer:', error);
    }
}

function createVideoModal() {
    const modal = document.createElement('div');
    modal.id = 'videoModal';
    modal.className = 'video-modal';
    
    modal.innerHTML = `
        <div class="video-modal-content">
            <span class="close-video">&times;</span>
            <div class="video-container"></div>
        </div>
    `;

    // Add close button functionality
    const closeBtn = modal.querySelector('.close-video');
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
        const videoContainer = modal.querySelector('.video-container');
        videoContainer.innerHTML = ''; // Clear the iframe
    });

    // Close on click outside
    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
            const videoContainer = modal.querySelector('.video-container');
            videoContainer.innerHTML = ''; // Clear the iframe
        }
    });

    document.body.appendChild(modal);
    return modal;
}

function displayNoResults(searchTerm) {
    searchResults.innerHTML = `
        <div class="no-results">
            <i class="fas fa-search" style="font-size: 2rem; margin-bottom: 10px;"></i>
            <p>No results found for "${escapeHtml(searchTerm)}"</p>
            <p class="no-results-suggestion">Try different keywords or check the spelling</p>
        </div>
    `;
}

function displayError() {
    searchResults.innerHTML = `
        <div class="no-results">
            <i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 10px; color: var(--primary-red);"></i>
            <p>An error occurred while searching. Please try again.</p>
        </div>
    `;
}

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
} 