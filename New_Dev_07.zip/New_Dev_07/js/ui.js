// UI Handler
const UI = {
    // Show/Hide Loading
    showLoading() {
        const loader = document.querySelector('.page-loader');
        const loaderContent = document.querySelector('.loader-content');
        if (loader) loader.style.display = 'flex';
        if (loaderContent) loaderContent.style.display = 'flex';
    },

    hideLoading() {
        const loader = document.querySelector('.page-loader');
        const loaderContent = document.querySelector('.loader-content');
        if (loader) loader.style.display = 'none';
        if (loaderContent) loaderContent.style.display = 'none';
    },

    // Show Messages
    showMessage(message, type = 'success') {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.textContent = message;
        document.body.appendChild(messageDiv);

        setTimeout(() => {
            messageDiv.remove();
        }, 3000);
    },

    // Movie Card Template
    createMovieCard(movie) {
        if (!movie) return '';
        return `
            <div class="cards" data-category="${movie.genre.toLowerCase()}">
                <div class="card-img" style="background-image: url('${movie.poster_url}');">
                    <div class="img-title">
                        <h3>${movie.title}</h3>
                        <span>${movie.release_year} • ${movie.genre}</span>
                    </div>
                </div>
                <div class="card-title">
                    <h4>${movie.rating}</h4>
                    <p>IMDb</p>
                </div>
            </div>
        `;
    },

    // TV Series Card Template
    createTVSeriesCard(series) {
        if (!series) return '';
        return `
            <div class="cards" data-category="${series.genre.toLowerCase()}">
                <div class="card-img" style="background-image: url('${series.poster_url}');">
                    <div class="img-title">
                        <h3>${series.title}</h3>
                        <span>${series.start_year}-${series.end_year} • ${series.genre}</span>
                    </div>
                </div>
                <div class="card-title">
                    <h4>${series.rating}</h4>
                    <p>IMDb</p>
                </div>
            </div>
        `;
    },

    // Update Movie List
    updateMovieList(movies) {
        const movieContainer = document.querySelector('.movies-card');
        if (!movieContainer) return;
        if (!movies || !movies.length) {
            movieContainer.innerHTML = '<div class="no-content">No movies available</div>';
            return;
        }
        movieContainer.innerHTML = movies.map(movie => this.createMovieCard(movie)).join('');
    },

    // Update TV Series List
    updateTVSeriesList(series) {
        const seriesContainer = document.querySelector('.owl-carousel');
        if (!seriesContainer) return;
        if (!series || !series.length) {
            seriesContainer.innerHTML = '<div class="no-content">No TV series available</div>';
            return;
        }
        seriesContainer.innerHTML = series.map(s => this.createTVSeriesCard(s)).join('');
        
        // Reinitialize Owl Carousel
        if (typeof $.fn.owlCarousel !== 'undefined') {
            $(seriesContainer).trigger('destroy.owl.carousel').owlCarousel({
                loop: true,
                margin: 10,
                nav: true,
                responsive: {
                    0: { items: 1 },
                    600: { items: 3 },
                    1000: { items: 5 }
                }
            });
        }
    },

    // Show/Hide Trailer Modal
    showTrailerModal(trailerUrl) {
        const modal = document.getElementById('trailerModal');
        const iframe = document.getElementById('trailerFrame');
        if (!modal || !iframe || !trailerUrl) return;

        iframe.src = trailerUrl;
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('show'), 10);
    },

    hideTrailerModal() {
        const modal = document.getElementById('trailerModal');
        const iframe = document.getElementById('trailerFrame');
        if (!modal || !iframe) return;

        modal.classList.remove('show');
        setTimeout(() => {
            modal.style.display = 'none';
            iframe.src = '';
        }, 300);
    },

    // Show/Hide Search Modal
    showSearchModal() {
        const modal = document.querySelector('.search-modal');
        const searchInput = document.querySelector('.search-input');
        if (modal) {
            modal.style.display = 'block';
            setTimeout(() => {
                modal.classList.add('show');
                if (searchInput) searchInput.focus();
            }, 10);
        }
    },

    hideSearchModal() {
        const modal = document.querySelector('.search-modal');
        const searchInput = document.querySelector('.search-input');
        if (modal) {
            modal.classList.remove('show');
            if (searchInput) searchInput.value = '';
            setTimeout(() => modal.style.display = 'none', 300);
        }
    },

    // Update Search Results
    updateSearchResults(results) {
        const resultsContainer = document.querySelector('.search-results');
        if (!resultsContainer) return;

        if (!results || !results.length) {
            resultsContainer.innerHTML = '<div class="no-results">No results found</div>';
            return;
        }

        resultsContainer.innerHTML = results.map(result => `
            <div class="search-result-item">
                <div class="result-poster" style="background-image: url('${result.poster_url}')"></div>
                <div class="result-info">
                    <h3>${result.title}</h3>
                    <p>${result.genre}</p>
                </div>
            </div>
        `).join('');
    }
}; 