// Static Data
const moviesData = [
    {
        id: 1,
        title: "Spider-Man: No Way Home",
        genre: "Action",
        rating: "8.3",
        release_year: "2021",
        poster_url: "spiderman no way home.jpeg",
        description: "When Peter Parker's world is turned upside down, he seeks help from Doctor Strange, but things soon become much more dangerous.",
        trailerUrl: "https://www.youtube.com/embed/JfVOs4VSpmA"
    },
    {
        id: 2,
        title: "The Black Phone",
        genre: "Horror",
        rating: "7.0",
        release_year: "2021",
        poster_url: "the black phone.jpeg",
        description: "After being abducted by a child killer and locked in a soundproof basement, a 13-year-old boy starts receiving calls on a disconnected phone from the killer's previous victims."
    },
    {
        id: 3,
        title: "Jurassic World Dominion",
        genre: "Adventure",
        rating: "6.6",
        release_year: "2022",
        poster_url: "jurrasic world dominion.jpeg",
        description: "Four years after the destruction of Isla Nublar, dinosaurs now live and hunt alongside humans all over the world."
    },
    {
        id: 4,
        title: "Minions: The Rise of Gru",
        genre: "Animation",
        rating: "7.8",
        release_year: "2022",
        poster_url: "minions.jpeg",
        description: "The untold story of one twelve-year-old's dream to become the world's greatest supervillain."
    },
    {
        id: 5,
        title: "The Irishman",
        genre: "Biography",
        rating: "7.8",
        release_year: "2019",
        poster_url: "irish man.jpeg",
        description: "An aging hitman recalls his time with the mob and the intersecting events with his friend, Jimmy Hoffa, through the 1950-70s."
    },
    {
        id: 6,
        title: "Matrix Resurrection",
        genre: "Action",
        rating: "5.7",
        release_year: "2021",
        poster_url: "matrix.jpeg",
        description: "Return to a world of two realities: one, everyday life; the other, what lies behind it. To find out if his reality is a construct, Mr. Anderson will have to choose to follow the white rabbit once more."
    }
];

const tvSeriesData = [
    {
        id: 1,
        title: "Breaking Bad",
        genre: "Crime",
        rating: "9.5",
        start_year: "2008",
        end_year: "2013",
        poster_url: "breaking bad.jpeg",
        description: "A high school chemistry teacher turned methamphetamine manufacturer partners with a former student to secure his family's financial future."
    },
    {
        id: 2,
        title: "Game of Thrones",
        genre: "Action",
        rating: "9.2",
        start_year: "2011",
        end_year: "2019",
        poster_url: "game of thrones.jpeg",
        description: "Nine noble families fight for control over the lands of Westeros, while an ancient enemy returns after being dormant for millennia."
    },
    {
        id: 3,
        title: "Friends",
        genre: "Comedy",
        rating: "8.2",
        start_year: "1994",
        end_year: "2004",
        poster_url: "friends.jpeg",
        description: "Follows the personal and professional lives of six twenty to thirty-something-year-old friends living in Manhattan."
    },
    {
        id: 4,
        title: "Wednesday",
        genre: "Comedy",
        rating: "8.2",
        start_year: "2022",
        end_year: "2022",
        poster_url: "wednesday.jpeg",
        description: "Follows Wednesday Addams' years as a student at Nevermore Academy, where she attempts to master her psychic powers."
    },
    {
        id: 5,
        title: "Mr. Robot",
        genre: "Crime",
        rating: "8.6",
        start_year: "2015",
        end_year: "2019",
        poster_url: "mr robot.jpeg",
        description: "A hacker joins a group of hacktivists to destroy all debt records."
    }
];

// Simple Data Management
const DataManager = {
    getMovies() {
        return moviesData;
    },

    getTVSeries() {
        return tvSeriesData;
    },

    searchContent(query) {
        query = query.toLowerCase();
        const movies = moviesData.filter(movie => 
            movie.title.toLowerCase().includes(query) ||
            movie.description.toLowerCase().includes(query)
        );
        const series = tvSeriesData.filter(series => 
            series.title.toLowerCase().includes(query) ||
            series.description.toLowerCase().includes(query)
        );
        return [...movies, ...series];
    },

    filterByCategory(category) {
        if (category === 'all') return moviesData;
        return moviesData.filter(movie => movie.genre.toLowerCase() === category.toLowerCase());
    }
}; 