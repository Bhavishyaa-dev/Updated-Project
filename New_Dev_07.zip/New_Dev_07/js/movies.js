const API_URL = 'http://localhost:5000/api';

// Get all movies
async function getMovies() {
    try {
        const response = await fetch(`${API_URL}/movies`);
        const data = await response.json();
        if (data.success) {
            displayMovies(data.data);
        } else {
            throw new Error(data.error);
        }
    } catch (error) {
        console.error('Error fetching movies:', error);
        showError('Failed to load movies');
    }
}

// Display movies in the UI
function displayMovies(movies) {
    const moviesContainer = document.querySelector('.movies-card');
    if (!moviesContainer) return;

    moviesContainer.innerHTML = movies.map(movie => `
        <div class="cards" data-category="${movie.genre || 'action'}">
            <div class="card-img" style="background-image: url('${movie.poster_url || 'default-movie.jpg'}');">
                <div class="img-title">
                    <h3>${movie.title}</h3>
                    <span>${movie.release_year} • ${movie.genre || 'Action'}</span>
                </div>
            </div>
            <div class="card-title">
                <h4>${movie.rating || 'N/A'}</h4>
                <p>IMDb</p>
            </div>
        </div>
    `).join('');
}

// Filter movies by category
function filterMovies(category) {
    const allMovies = document.querySelectorAll('.movies-card .cards');
    allMovies.forEach(movie => {
        if (category === 'All' || movie.dataset.category === category.toLowerCase()) {
            movie.style.display = 'block';
        } else {
            movie.style.display = 'none';
        }
    });
}

// Search movies
async function searchMovies(query) {
    try {
        const response = await fetch(`${API_URL}/movies/search?q=${encodeURIComponent(query)}`);
        const data = await response.json();
        if (data.success) {
            displaySearchResults(data.data);
        } else {
            throw new Error(data.error);
        }
    } catch (error) {
        console.error('Search error:', error);
        showError('Search failed');
    }
}

// Display search results
function displaySearchResults(movies) {
    const searchResults = document.querySelector('.search-results');
    if (!searchResults) return;

    if (movies.length === 0) {
        searchResults.innerHTML = '<p>No movies found</p>';
        return;
    }

    searchResults.innerHTML = movies.map(movie => `
        <div class="search-result-item">
            <img src="${movie.poster_url || 'default-movie.jpg'}" alt="${movie.title}">
            <div class="search-result-info">
                <h3>${movie.title}</h3>
                <p>${movie.release_year} • ${movie.duration} min</p>
                <p>${movie.description.substring(0, 100)}...</p>
            </div>
        </div>
    `).join('');
}

// Initialize movie functionality
document.addEventListener('DOMContentLoaded', () => {
    // Load movies when page loads
    getMovies();

    // Set up category filter buttons
    const filterButtons = document.querySelectorAll('.movies-ctg .btn');
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            filterMovies(button.textContent);
        });
    });

    // Set up search
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            if (e.target.value.length >= 3) {
                searchMovies(e.target.value);
            }
        });
    }
}); 