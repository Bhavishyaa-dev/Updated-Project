// Initialize Swiper
const swiper = new Swiper('.mySwiper', {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    autoplay: {
        delay: 5000,
        disableOnInteraction: false,
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },
    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },
});

// Initialize Owl Carousel
$(document).ready(function() {
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: { items: 1 },
            600: { items: 3 },
            1000: { items: 5 }
        }
    });
});

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Show loading
    UI.showLoading();

    // Initialize UI with data
    UI.updateMovieList(DataManager.getMovies());
    UI.updateTVSeriesList(DataManager.getTVSeries());

    // Hide loading
    UI.hideLoading();

    // Navigation Toggle
    const openBtn = document.getElementById('open');
    const closeBtn = document.getElementById('close');
    const navItems = document.querySelector('.nav-items');

    if (openBtn && closeBtn && navItems) {
        openBtn.addEventListener('click', () => {
            navItems.style.right = '0';
        });

        closeBtn.addEventListener('click', () => {
            navItems.style.right = '-100%';
        });
    }

    // Search Functionality
    const searchIcon = document.querySelector('.fa-magnifying-glass');
    const closeSearch = document.querySelector('.close-search');
    const searchInput = document.querySelector('.search-input');

    if (searchIcon) {
        searchIcon.addEventListener('click', () => {
            UI.showSearchModal();
        });
    }

    if (closeSearch) {
        closeSearch.addEventListener('click', () => {
            UI.hideSearchModal();
        });
    }

    if (searchInput) {
        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const query = e.target.value.toLowerCase();
                const results = DataManager.searchContent(query);
                UI.updateSearchResults(results);
            }, 300);
        });
    }

    // Trailer Modal
    const trailerButtons = document.querySelectorAll('.btn-2');
    const closeModal = document.querySelector('.close-modal');

    trailerButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            const card = e.target.closest('.swiper-slide');
            if (card && card.dataset.trailerUrl) {
                UI.showTrailerModal(card.dataset.trailerUrl);
            }
        });
    });

    if (closeModal) {
        closeModal.addEventListener('click', () => {
            UI.hideTrailerModal();
        });
    }

    // Movie Category Filter
    const categoryButtons = document.querySelectorAll('.movies-ctg .btn');

    categoryButtons.forEach(button => {
        button.addEventListener('click', () => {
            const category = button.textContent.toLowerCase();
            
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');

            const filteredMovies = DataManager.filterByCategory(category);
            UI.updateMovieList(filteredMovies);
        });
    });

    // Subscribe Form
    const subscribeBtn = document.getElementById('subscribeBtn');
    const emailInput = document.getElementById('emailInput');
    const subscribeMessage = document.getElementById('subscribeMessage');

    if (subscribeBtn && emailInput && subscribeMessage) {
        subscribeBtn.addEventListener('click', () => {
            const email = emailInput.value.trim();
            if (email && email.includes('@')) {
                subscribeMessage.textContent = 'Thank you for subscribing!';
                subscribeMessage.className = 'subscribe-message success';
                emailInput.value = '';
            } else {
                subscribeMessage.textContent = 'Please enter a valid email address.';
                subscribeMessage.className = 'subscribe-message error';
            }
            subscribeMessage.style.display = 'block';
        });
    }
}); 