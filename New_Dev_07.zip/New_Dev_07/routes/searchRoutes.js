const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');

// Search movies and TV series
router.get('/', async (req, res) => {
    try {
        const { query, type, genre, year, sort } = req.query;
        let movieQuery = `
            SELECT 
                m.id,
                'movie' as type,
                m.title,
                m.description,
                m.release_year,
                m.rating,
                m.poster_url,
                m.trailer_url,
                GROUP_CONCAT(DISTINCT g.name) as genres
            FROM movies m
            LEFT JOIN movie_genres mg ON m.id = mg.movie_id
            LEFT JOIN genres g ON mg.genre_id = g.id
        `;
        let seriesQuery = `
            SELECT 
                s.id,
                'series' as type,
                s.title,
                s.description,
                s.release_year,
                s.rating,
                s.poster_url,
                s.trailer_url,
                GROUP_CONCAT(DISTINCT g.name) as genres
            FROM series s
            LEFT JOIN series_genres sg ON s.id = sg.series_id
            LEFT JOIN genres g ON sg.genre_id = g.id
        `;

        const queryParams = [];
        let conditions = [];

        // Search by title or description
        if (query) {
            conditions.push('(title LIKE ? OR description LIKE ?)');
            const searchTerm = `%${query}%`;
            queryParams.push(searchTerm, searchTerm);
        }

        // Filter by genre
        if (genre) {
            conditions.push('g.name = ?');
            queryParams.push(genre);
        }

        // Filter by year
        if (year) {
            conditions.push('release_year = ?');
            queryParams.push(year);
        }

        // Add WHERE clause if conditions exist
        if (conditions.length) {
            const whereClause = 'WHERE ' + conditions.join(' AND ');
            movieQuery += ' ' + whereClause;
            seriesQuery += ' ' + whereClause;
        }

        // Add GROUP BY
        movieQuery += ' GROUP BY m.id';
        seriesQuery += ' GROUP BY s.id';

        // Add sorting
        const sortClause = sort === 'rating' ? 'ORDER BY rating DESC' :
                          sort === 'year' ? 'ORDER BY release_year DESC' :
                          'ORDER BY title ASC';
        movieQuery += ' ' + sortClause;
        seriesQuery += ' ' + sortClause;

        // Execute queries based on type
        let results = [];
        if (!type || type === 'movie') {
            const [movies] = await pool.execute(movieQuery, queryParams);
            results = results.concat(movies);
        }
        if (!type || type === 'series') {
            const [series] = await pool.execute(seriesQuery, queryParams);
            results = results.concat(series);
        }

        // Sort combined results if needed
        if (sort === 'rating') {
            results.sort((a, b) => b.rating - a.rating);
        } else if (sort === 'year') {
            results.sort((a, b) => b.release_year - a.release_year);
        } else {
            results.sort((a, b) => a.title.localeCompare(b.title));
        }

        res.json({
            success: true,
            data: results
        });
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({
            success: false,
            message: 'Error performing search'
        });
    }
});

// Get available genres
router.get('/genres', async (req, res) => {
    try {
        const [genres] = await pool.execute('SELECT * FROM genres ORDER BY name');
        res.json({
            success: true,
            data: genres
        });
    } catch (error) {
        console.error('Get genres error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting genres'
        });
    }
});

// Get available years
router.get('/years', async (req, res) => {
    try {
        const [movieYears] = await pool.execute(
            'SELECT DISTINCT release_year FROM movies WHERE release_year IS NOT NULL'
        );
        const [seriesYears] = await pool.execute(
            'SELECT DISTINCT release_year FROM series WHERE release_year IS NOT NULL'
        );

        // Combine and deduplicate years
        const years = [...new Set([
            ...movieYears.map(m => m.release_year),
            ...seriesYears.map(s => s.release_year)
        ])].sort((a, b) => b - a);

        res.json({
            success: true,
            data: years
        });
    } catch (error) {
        console.error('Get years error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting years'
        });
    }
});

module.exports = router; 