const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { protect } = require('../middleware/auth');

// Get user's watchlist
router.get('/', protect, async (req, res) => {
    try {
        const [watchlist] = await pool.execute(`
            SELECT w.*, 
                CASE 
                    WHEN w.content_type = 'movie' THEN m.title 
                    ELSE s.title 
                END as title,
                CASE 
                    WHEN w.content_type = 'movie' THEN m.poster_url 
                    ELSE s.poster_url 
                END as poster_url,
                CASE 
                    WHEN w.content_type = 'movie' THEN m.rating 
                    ELSE s.rating 
                END as rating
            FROM watchlist w
            LEFT JOIN movies m ON w.content_type = 'movie' AND w.content_id = m.id
            LEFT JOIN series s ON w.content_type = 'series' AND w.content_id = s.id
            WHERE w.user_id = ?
            ORDER BY w.created_at DESC
        `, [req.user.id]);

        res.json({
            success: true,
            data: watchlist
        });
    } catch (error) {
        console.error('Get watchlist error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting watchlist'
        });
    }
});

// Add to watchlist
router.post('/', protect, async (req, res) => {
    try {
        const { content_type, content_id } = req.body;

        // Validate content type
        if (!['movie', 'series'].includes(content_type)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid content type'
            });
        }

        // Check if content exists
        const [content] = await pool.execute(
            content_type === 'movie'
                ? 'SELECT id FROM movies WHERE id = ?'
                : 'SELECT id FROM series WHERE id = ?',
            [content_id]
        );

        if (!content.length) {
            return res.status(404).json({
                success: false,
                message: `${content_type === 'movie' ? 'Movie' : 'TV series'} not found`
            });
        }

        // Check if already in watchlist
        const [existing] = await pool.execute(
            'SELECT id FROM watchlist WHERE user_id = ? AND content_type = ? AND content_id = ?',
            [req.user.id, content_type, content_id]
        );

        if (existing.length) {
            return res.status(400).json({
                success: false,
                message: 'Already in watchlist'
            });
        }

        // Add to watchlist
        await pool.execute(
            'INSERT INTO watchlist (user_id, content_type, content_id) VALUES (?, ?, ?)',
            [req.user.id, content_type, content_id]
        );

        res.status(201).json({
            success: true,
            message: 'Added to watchlist'
        });
    } catch (error) {
        console.error('Add to watchlist error:', error);
        res.status(500).json({
            success: false,
            message: 'Error adding to watchlist'
        });
    }
});

// Remove from watchlist
router.delete('/:id', protect, async (req, res) => {
    try {
        // Check if item exists and belongs to user
        const [existing] = await pool.execute(
            'SELECT id FROM watchlist WHERE id = ? AND user_id = ?',
            [req.params.id, req.user.id]
        );

        if (!existing.length) {
            return res.status(404).json({
                success: false,
                message: 'Watchlist item not found'
            });
        }

        // Remove from watchlist
        await pool.execute(
            'DELETE FROM watchlist WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            message: 'Removed from watchlist'
        });
    } catch (error) {
        console.error('Remove from watchlist error:', error);
        res.status(500).json({
            success: false,
            message: 'Error removing from watchlist'
        });
    }
});

module.exports = router; 