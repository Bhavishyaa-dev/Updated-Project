const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { protect, authorize } = require('../middleware/auth');

// Get all TV series
router.get('/', async (req, res) => {
    try {
        const [series] = await pool.execute(
            'SELECT s.*, GROUP_CONCAT(g.name) as genres FROM series s ' +
            'LEFT JOIN series_genres sg ON s.id = sg.series_id ' +
            'LEFT JOIN genres g ON sg.genre_id = g.id ' +
            'GROUP BY s.id'
        );

        res.json({
            success: true,
            data: series
        });
    } catch (error) {
        console.error('Get series error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting TV series'
        });
    }
});

// Get single TV series
router.get('/:id', async (req, res) => {
    try {
        const [series] = await pool.execute(
            'SELECT s.*, GROUP_CONCAT(g.name) as genres FROM series s ' +
            'LEFT JOIN series_genres sg ON s.id = sg.series_id ' +
            'LEFT JOIN genres g ON sg.genre_id = g.id ' +
            'WHERE s.id = ? ' +
            'GROUP BY s.id',
            [req.params.id]
        );

        if (!series.length) {
            return res.status(404).json({
                success: false,
                message: 'TV series not found'
            });
        }

        // Get seasons and episodes
        const [seasons] = await pool.execute(
            'SELECT * FROM seasons WHERE series_id = ? ORDER BY season_number',
            [req.params.id]
        );

        for (const season of seasons) {
            const [episodes] = await pool.execute(
                'SELECT * FROM episodes WHERE season_id = ? ORDER BY episode_number',
                [season.id]
            );
            season.episodes = episodes;
        }

        series[0].seasons = seasons;

        res.json({
            success: true,
            data: series[0]
        });
    } catch (error) {
        console.error('Get series error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting TV series'
        });
    }
});

// Add TV series (Admin only)
router.post('/', protect, authorize('admin'), async (req, res) => {
    try {
        const {
            title,
            description,
            release_year,
            rating,
            poster_url,
            trailer_url,
            genres,
            seasons
        } = req.body;

        // Insert series
        const [result] = await pool.execute(
            'INSERT INTO series (title, description, release_year, rating, poster_url, trailer_url) ' +
            'VALUES (?, ?, ?, ?, ?, ?)',
            [title, description, release_year, rating, poster_url, trailer_url]
        );

        const seriesId = result.insertId;

        // Add genres
        if (genres && genres.length) {
            const values = genres.map(genreId => [seriesId, genreId]);
            await pool.execute(
                'INSERT INTO series_genres (series_id, genre_id) VALUES ?',
                [values]
            );
        }

        // Add seasons and episodes
        if (seasons && seasons.length) {
            for (const season of seasons) {
                const [seasonResult] = await pool.execute(
                    'INSERT INTO seasons (series_id, season_number, title) VALUES (?, ?, ?)',
                    [seriesId, season.season_number, season.title]
                );

                if (season.episodes && season.episodes.length) {
                    const episodeValues = season.episodes.map(episode => [
                        seasonResult.insertId,
                        episode.episode_number,
                        episode.title,
                        episode.description,
                        episode.duration,
                        episode.video_url
                    ]);

                    await pool.execute(
                        'INSERT INTO episodes (season_id, episode_number, title, description, duration, video_url) VALUES ?',
                        [episodeValues]
                    );
                }
            }
        }

        res.status(201).json({
            success: true,
            message: 'TV series added successfully'
        });
    } catch (error) {
        console.error('Add series error:', error);
        res.status(500).json({
            success: false,
            message: 'Error adding TV series'
        });
    }
});

// Update TV series (Admin only)
router.put('/:id', protect, authorize('admin'), async (req, res) => {
    try {
        const {
            title,
            description,
            release_year,
            rating,
            poster_url,
            trailer_url,
            genres
        } = req.body;

        // Check if series exists
        const [existingSeries] = await pool.execute(
            'SELECT id FROM series WHERE id = ?',
            [req.params.id]
        );

        if (!existingSeries.length) {
            return res.status(404).json({
                success: false,
                message: 'TV series not found'
            });
        }

        // Update series
        await pool.execute(
            'UPDATE series SET title = ?, description = ?, release_year = ?, ' +
            'rating = ?, poster_url = ?, trailer_url = ? WHERE id = ?',
            [title, description, release_year, rating, poster_url, trailer_url, req.params.id]
        );

        // Update genres
        if (genres) {
            // Remove existing genres
            await pool.execute(
                'DELETE FROM series_genres WHERE series_id = ?',
                [req.params.id]
            );

            // Add new genres
            if (genres.length) {
                const values = genres.map(genreId => [req.params.id, genreId]);
                await pool.execute(
                    'INSERT INTO series_genres (series_id, genre_id) VALUES ?',
                    [values]
                );
            }
        }

        res.json({
            success: true,
            message: 'TV series updated successfully'
        });
    } catch (error) {
        console.error('Update series error:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating TV series'
        });
    }
});

// Delete TV series (Admin only)
router.delete('/:id', protect, authorize('admin'), async (req, res) => {
    try {
        // Check if series exists
        const [existingSeries] = await pool.execute(
            'SELECT id FROM series WHERE id = ?',
            [req.params.id]
        );

        if (!existingSeries.length) {
            return res.status(404).json({
                success: false,
                message: 'TV series not found'
            });
        }

        // Delete series (this will cascade delete related records)
        await pool.execute(
            'DELETE FROM series WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            message: 'TV series deleted successfully'
        });
    } catch (error) {
        console.error('Delete series error:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting TV series'
        });
    }
});

// Add TV series rating
router.post('/:id/rate', protect, async (req, res) => {
    try {
        const { rating } = req.body;

        // Check if series exists
        const [existingSeries] = await pool.execute(
            'SELECT id FROM series WHERE id = ?',
            [req.params.id]
        );

        if (!existingSeries.length) {
            return res.status(404).json({
                success: false,
                message: 'TV series not found'
            });
        }

        // Check if user has already rated
        const [existingRating] = await pool.execute(
            'SELECT id FROM series_ratings WHERE series_id = ? AND user_id = ?',
            [req.params.id, req.user.id]
        );

        if (existingRating.length) {
            // Update existing rating
            await pool.execute(
                'UPDATE series_ratings SET rating = ? WHERE series_id = ? AND user_id = ?',
                [rating, req.params.id, req.user.id]
            );
        } else {
            // Add new rating
            await pool.execute(
                'INSERT INTO series_ratings (series_id, user_id, rating) VALUES (?, ?, ?)',
                [req.params.id, req.user.id, rating]
            );
        }

        // Update average rating
        await pool.execute(
            'UPDATE series s SET rating = ' +
            '(SELECT AVG(rating) FROM series_ratings WHERE series_id = ?) ' +
            'WHERE id = ?',
            [req.params.id, req.params.id]
        );

        res.json({
            success: true,
            message: 'Rating added successfully'
        });
    } catch (error) {
        console.error('Add rating error:', error);
        res.status(500).json({
            success: false,
            message: 'Error adding rating'
        });
    }
});

module.exports = router; 