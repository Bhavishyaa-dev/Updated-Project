const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { protect, authorize } = require('../middleware/auth');

// @route   GET /api/movies
// @desc    Get all movies with optional filtering and sorting
// @access  Public
router.get('/', async (req, res) => {
    try {
        const { genre, sort, search } = req.query;
        let query = 'SELECT m.*, GROUP_CONCAT(g.name) as genres FROM movies m ' +
                    'LEFT JOIN movie_genres mg ON m.id = mg.movie_id ' +
                    'LEFT JOIN genres g ON mg.genre_id = g.id ' +
                    'GROUP BY m.id';
        const queryParams = [];

        if (search) {
            query += ' WHERE m.title LIKE ? OR m.description LIKE ?';
            queryParams.push(`%${search}%`, `%${search}%`);
        }

        if (genre) {
            query += search ? ' AND' : ' WHERE';
            query += ' g.name = ?';
            queryParams.push(genre);
        }

        if (sort) {
            switch (sort) {
                case 'rating':
                    query += ' ORDER BY m.rating DESC';
                    break;
                case 'newest':
                    query += ' ORDER BY m.created_at DESC';
                    break;
                case 'views':
                    query += ' ORDER BY m.views DESC';
                    break;
                default:
                    query += ' ORDER BY m.created_at DESC';
            }
        }

        const [movies] = await pool.execute(query, queryParams);

        res.json({
            success: true,
            count: movies.length,
            movies
        });
    } catch (error) {
        console.error('Get movies error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting movies'
        });
    }
});

// @route   GET /api/movies/:id
// @desc    Get single movie
// @access  Public
router.get('/:id', async (req, res) => {
    try {
        const [movies] = await pool.execute(
            'SELECT m.*, GROUP_CONCAT(g.name) as genres FROM movies m ' +
            'LEFT JOIN movie_genres mg ON m.id = mg.movie_id ' +
            'LEFT JOIN genres g ON mg.genre_id = g.id ' +
            'WHERE m.id = ? ' +
            'GROUP BY m.id',
            [req.params.id]
        );

        if (!movies.length) {
            return res.status(404).json({
                success: false,
                message: 'Movie not found'
            });
        }

        // Increment views
        await pool.execute(
            'UPDATE movies SET views = views + 1 WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            movie: movies[0]
        });
    } catch (error) {
        console.error('Get movie error:', error);
        res.status(500).json({
            success: false,
            message: 'Error getting movie'
        });
    }
});

// @route   POST /api/movies
// @desc    Create a new movie (admin only)
// @access  Private/Admin
router.post('/', protect, authorize('admin'), async (req, res) => {
    try {
        const {
            title,
            description,
            release_year,
            duration,
            rating,
            poster_url,
            trailer_url,
            genres
        } = req.body;

        // Insert movie
        const [result] = await pool.execute(
            'INSERT INTO movies (title, description, release_year, duration, rating, poster_url, trailer_url) ' +
            'VALUES (?, ?, ?, ?, ?, ?, ?)',
            [title, description, release_year, duration, rating, poster_url, trailer_url]
        );

        const movieId = result.insertId;

        // Add genres
        if (genres && genres.length) {
            const values = genres.map(genreId => [movieId, genreId]);
            await pool.execute(
                'INSERT INTO movie_genres (movie_id, genre_id) VALUES ?',
                [values]
            );
        }

        res.status(201).json({
            success: true,
            message: 'Movie added successfully'
        });
    } catch (error) {
        console.error('Add movie error:', error);
        res.status(500).json({
            success: false,
            message: 'Error adding movie'
        });
    }
});

// @route   PUT /api/movies/:id
// @desc    Update a movie (admin only)
// @access  Private/Admin
router.put('/:id', protect, authorize('admin'), async (req, res) => {
    try {
        const {
            title,
            description,
            release_year,
            duration,
            rating,
            poster_url,
            trailer_url,
            genres
        } = req.body;

        // Check if movie exists
        const [existingMovie] = await pool.execute(
            'SELECT id FROM movies WHERE id = ?',
            [req.params.id]
        );

        if (!existingMovie.length) {
            return res.status(404).json({
                success: false,
                message: 'Movie not found'
            });
        }

        // Update movie
        await pool.execute(
            'UPDATE movies SET title = ?, description = ?, release_year = ?, ' +
            'duration = ?, rating = ?, poster_url = ?, trailer_url = ? WHERE id = ?',
            [title, description, release_year, duration, rating, poster_url, trailer_url, req.params.id]
        );

        // Update genres
        if (genres) {
            // Remove existing genres
            await pool.execute(
                'DELETE FROM movie_genres WHERE movie_id = ?',
                [req.params.id]
            );

            // Add new genres
            if (genres.length) {
                const values = genres.map(genreId => [req.params.id, genreId]);
                await pool.execute(
                    'INSERT INTO movie_genres (movie_id, genre_id) VALUES ?',
                    [values]
                );
            }
        }

        res.json({
            success: true,
            message: 'Movie updated successfully'
        });
    } catch (error) {
        console.error('Update movie error:', error);
        res.status(500).json({
            success: false,
            message: 'Error updating movie'
        });
    }
});

// @route   DELETE /api/movies/:id
// @desc    Delete a movie (admin only)
// @access  Private/Admin
router.delete('/:id', protect, authorize('admin'), async (req, res) => {
    try {
        // Check if movie exists
        const [existingMovie] = await pool.execute(
            'SELECT id FROM movies WHERE id = ?',
            [req.params.id]
        );

        if (!existingMovie.length) {
            return res.status(404).json({
                success: false,
                message: 'Movie not found'
            });
        }

        // Delete movie (this will cascade delete related records)
        await pool.execute(
            'DELETE FROM movies WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            message: 'Movie deleted successfully'
        });
    } catch (error) {
        console.error('Delete movie error:', error);
        res.status(500).json({
            success: false,
            message: 'Error deleting movie'
        });
    }
});

// @route   POST /api/movies/:id/comments
// @desc    Add a comment to a movie
// @access  Private
router.post('/:id/comments', protect, async (req, res) => {
    try {
        const { text } = req.body;

        await pool.execute(
            'INSERT INTO comments (user_id, movie_id, text) VALUES (?, ?, ?)',
            [req.user.id, req.params.id, text]
        );

        const [comment] = await pool.execute(
            'SELECT c.*, u.name, u.profile_picture FROM comments c JOIN users u ON c.user_id = u.id WHERE c.movie_id = ? AND c.user_id = ? ORDER BY c.created_at DESC LIMIT 1',
            [req.params.id, req.user.id]
        );

        res.status(201).json({
            success: true,
            comment: comment[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/movies/:id/like
// @desc    Like a movie
// @access  Private
router.post('/:id/like', protect, async (req, res) => {
    try {
        // Check if user has already rated
        const [existingRating] = await pool.execute(
            'SELECT * FROM user_ratings WHERE user_id = ? AND movie_id = ?',
            [req.user.id, req.params.id]
        );

        if (existingRating.length) {
            if (existingRating[0].rating === 'like') {
                return res.status(400).json({
                    success: false,
                    message: 'You have already liked this movie'
                });
            }

            // Update existing rating
            await pool.execute(
                'UPDATE user_ratings SET rating = ? WHERE user_id = ? AND movie_id = ?',
                ['like', req.user.id, req.params.id]
            );

            // Update movie likes/dislikes
            await pool.execute(
                'UPDATE movies SET likes = likes + 1, dislikes = dislikes - 1 WHERE id = ?',
                [req.params.id]
            );
        } else {
            // Create new rating
            await pool.execute(
                'INSERT INTO user_ratings (user_id, movie_id, rating) VALUES (?, ?, ?)',
                [req.user.id, req.params.id, 'like']
            );

            // Update movie likes
            await pool.execute(
                'UPDATE movies SET likes = likes + 1 WHERE id = ?',
                [req.params.id]
            );
        }

        const [movie] = await pool.execute(
            'SELECT likes, dislikes FROM movies WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            likes: movie[0].likes,
            dislikes: movie[0].dislikes
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/movies/:id/dislike
// @desc    Dislike a movie
// @access  Private
router.post('/:id/dislike', protect, async (req, res) => {
    try {
        // Check if user has already rated
        const [existingRating] = await pool.execute(
            'SELECT * FROM user_ratings WHERE user_id = ? AND movie_id = ?',
            [req.user.id, req.params.id]
        );

        if (existingRating.length) {
            if (existingRating[0].rating === 'dislike') {
                return res.status(400).json({
                    success: false,
                    message: 'You have already disliked this movie'
                });
            }

            // Update existing rating
            await pool.execute(
                'UPDATE user_ratings SET rating = ? WHERE user_id = ? AND movie_id = ?',
                ['dislike', req.user.id, req.params.id]
            );

            // Update movie likes/dislikes
            await pool.execute(
                'UPDATE movies SET likes = likes - 1, dislikes = dislikes + 1 WHERE id = ?',
                [req.params.id]
            );
        } else {
            // Create new rating
            await pool.execute(
                'INSERT INTO user_ratings (user_id, movie_id, rating) VALUES (?, ?, ?)',
                [req.user.id, req.params.id, 'dislike']
            );

            // Update movie dislikes
            await pool.execute(
                'UPDATE movies SET dislikes = dislikes + 1 WHERE id = ?',
                [req.params.id]
            );
        }

        const [movie] = await pool.execute(
            'SELECT likes, dislikes FROM movies WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            likes: movie[0].likes,
            dislikes: movie[0].dislikes
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   GET /api/movies/:id/comments
// @desc    Get all comments for a movie
// @access  Public
router.get('/:id/comments', async (req, res) => {
    try {
        const [comments] = await pool.execute(
            'SELECT c.*, u.name, u.profile_picture FROM comments c JOIN users u ON c.user_id = u.id WHERE c.movie_id = ? ORDER BY c.created_at DESC',
            [req.params.id]
        );

        res.json({
            success: true,
            count: comments.length,
            comments
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

module.exports = router; 