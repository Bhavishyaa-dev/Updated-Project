const express = require('express');
const router = express.Router();
const { pool } = require('../config/db');
const { protect, admin } = require('../middleware/auth');

// @route   GET /api/tv-series
// @desc    Get all TV series with optional filtering and sorting
// @access  Public
router.get('/', async (req, res) => {
    try {
        const { genre, sort, search } = req.query;
        let query = 'SELECT s.*, GROUP_CONCAT(sg.genre) as genres FROM tv_series s LEFT JOIN tv_series_genres sg ON s.id = sg.series_id';
        const queryParams = [];

        if (search) {
            query += ' WHERE s.title LIKE ? OR s.description LIKE ?';
            queryParams.push(`%${search}%`, `%${search}%`);
        }

        if (genre) {
            query += search ? ' AND' : ' WHERE';
            query += ' sg.genre = ?';
            queryParams.push(genre);
        }

        query += ' GROUP BY s.id';

        if (sort) {
            switch (sort) {
                case 'rating':
                    query += ' ORDER BY s.rating DESC';
                    break;
                case 'newest':
                    query += ' ORDER BY s.created_at DESC';
                    break;
                case 'views':
                    query += ' ORDER BY s.views DESC';
                    break;
                default:
                    query += ' ORDER BY s.created_at DESC';
            }
        }

        const [series] = await pool.query(query, queryParams);

        // Format genres
        series.forEach(s => {
            s.genres = s.genres ? s.genres.split(',') : [];
        });

        res.json({
            success: true,
            count: series.length,
            series
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   GET /api/tv-series/:id
// @desc    Get single TV series
// @access  Public
router.get('/:id', async (req, res) => {
    try {
        const [series] = await pool.query(
            'SELECT s.*, GROUP_CONCAT(sg.genre) as genres FROM tv_series s LEFT JOIN tv_series_genres sg ON s.id = sg.series_id WHERE s.id = ? GROUP BY s.id',
            [req.params.id]
        );

        if (!series[0]) {
            return res.status(404).json({
                success: false,
                message: 'TV series not found'
            });
        }

        // Format genres
        series[0].genres = series[0].genres ? series[0].genres.split(',') : [];

        // Get seasons and episodes
        const [seasons] = await pool.query(
            'SELECT s.*, COUNT(e.id) as episode_count FROM seasons s LEFT JOIN episodes e ON s.id = e.season_id WHERE s.series_id = ? GROUP BY s.id ORDER BY s.season_number',
            [req.params.id]
        );

        series[0].seasons = seasons;

        // Increment views
        await pool.query(
            'UPDATE tv_series SET views = views + 1 WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            series: series[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/tv-series
// @desc    Create a new TV series (admin only)
// @access  Private/Admin
router.post('/', protect, admin, async (req, res) => {
    try {
        const {
            title,
            description,
            start_year,
            end_year,
            poster_url,
            trailer_url,
            director,
            language,
            genres
        } = req.body;

        const [result] = await pool.query(
            'INSERT INTO tv_series (title, description, start_year, end_year, poster_url, trailer_url, director, language) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [title, description, start_year, end_year, poster_url, trailer_url, director, language]
        );

        // Add genres
        if (genres && genres.length > 0) {
            const genreValues = genres.map(genre => [result.insertId, genre]);
            await pool.query(
                'INSERT INTO tv_series_genres (series_id, genre) VALUES ?',
                [genreValues]
            );
        }

        const [series] = await pool.query(
            'SELECT s.*, GROUP_CONCAT(sg.genre) as genres FROM tv_series s LEFT JOIN tv_series_genres sg ON s.id = sg.series_id WHERE s.id = ? GROUP BY s.id',
            [result.insertId]
        );

        series[0].genres = series[0].genres ? series[0].genres.split(',') : [];

        res.status(201).json({
            success: true,
            series: series[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   PUT /api/tv-series/:id
// @desc    Update a TV series (admin only)
// @access  Private/Admin
router.put('/:id', protect, admin, async (req, res) => {
    try {
        const {
            title,
            description,
            start_year,
            end_year,
            poster_url,
            trailer_url,
            director,
            language,
            genres
        } = req.body;

        await pool.query(
            'UPDATE tv_series SET title = ?, description = ?, start_year = ?, end_year = ?, poster_url = ?, trailer_url = ?, director = ?, language = ? WHERE id = ?',
            [title, description, start_year, end_year, poster_url, trailer_url, director, language, req.params.id]
        );

        // Update genres
        if (genres) {
            await pool.query('DELETE FROM tv_series_genres WHERE series_id = ?', [req.params.id]);
            if (genres.length > 0) {
                const genreValues = genres.map(genre => [req.params.id, genre]);
                await pool.query(
                    'INSERT INTO tv_series_genres (series_id, genre) VALUES ?',
                    [genreValues]
                );
            }
        }

        const [series] = await pool.query(
            'SELECT s.*, GROUP_CONCAT(sg.genre) as genres FROM tv_series s LEFT JOIN tv_series_genres sg ON s.id = sg.series_id WHERE s.id = ? GROUP BY s.id',
            [req.params.id]
        );

        series[0].genres = series[0].genres ? series[0].genres.split(',') : [];

        res.json({
            success: true,
            series: series[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   DELETE /api/tv-series/:id
// @desc    Delete a TV series (admin only)
// @access  Private/Admin
router.delete('/:id', protect, admin, async (req, res) => {
    try {
        await pool.query('DELETE FROM tv_series WHERE id = ?', [req.params.id]);

        res.json({
            success: true,
            message: 'TV series deleted successfully'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/tv-series/:id/seasons
// @desc    Add a season to a TV series (admin only)
// @access  Private/Admin
router.post('/:id/seasons', protect, admin, async (req, res) => {
    try {
        const { season_number } = req.body;

        const [result] = await pool.query(
            'INSERT INTO seasons (series_id, season_number) VALUES (?, ?)',
            [req.params.id, season_number]
        );

        const [season] = await pool.query(
            'SELECT * FROM seasons WHERE id = ?',
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            season: season[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/tv-series/:id/seasons/:seasonId/episodes
// @desc    Add an episode to a season (admin only)
// @access  Private/Admin
router.post('/:id/seasons/:seasonId/episodes', protect, admin, async (req, res) => {
    try {
        const {
            episode_number,
            title,
            description,
            duration,
            video_url,
            thumbnail_url
        } = req.body;

        const [result] = await pool.query(
            'INSERT INTO episodes (season_id, episode_number, title, description, duration, video_url, thumbnail_url) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [req.params.seasonId, episode_number, title, description, duration, video_url, thumbnail_url]
        );

        const [episode] = await pool.query(
            'SELECT * FROM episodes WHERE id = ?',
            [result.insertId]
        );

        res.status(201).json({
            success: true,
            episode: episode[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/tv-series/:id/comments
// @desc    Add a comment to a TV series
// @access  Private
router.post('/:id/comments', protect, async (req, res) => {
    try {
        const { text } = req.body;

        await pool.query(
            'INSERT INTO comments (user_id, series_id, text) VALUES (?, ?, ?)',
            [req.user.id, req.params.id, text]
        );

        const [comment] = await pool.query(
            'SELECT c.*, u.name, u.profile_picture FROM comments c JOIN users u ON c.user_id = u.id WHERE c.series_id = ? AND c.user_id = ? ORDER BY c.created_at DESC LIMIT 1',
            [req.params.id, req.user.id]
        );

        res.status(201).json({
            success: true,
            comment: comment[0]
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/tv-series/:id/like
// @desc    Like a TV series
// @access  Private
router.post('/:id/like', protect, async (req, res) => {
    try {
        // Check if user has already rated
        const [existingRating] = await pool.query(
            'SELECT * FROM user_ratings WHERE user_id = ? AND series_id = ?',
            [req.user.id, req.params.id]
        );

        if (existingRating[0]) {
            if (existingRating[0].rating === 'like') {
                return res.status(400).json({
                    success: false,
                    message: 'You have already liked this series'
                });
            }

            // Update existing rating
            await pool.query(
                'UPDATE user_ratings SET rating = ? WHERE user_id = ? AND series_id = ?',
                ['like', req.user.id, req.params.id]
            );

            // Update series likes/dislikes
            await pool.query(
                'UPDATE tv_series SET likes = likes + 1, dislikes = dislikes - 1 WHERE id = ?',
                [req.params.id]
            );
        } else {
            // Create new rating
            await pool.query(
                'INSERT INTO user_ratings (user_id, series_id, rating) VALUES (?, ?, ?)',
                [req.user.id, req.params.id, 'like']
            );

            // Update series likes
            await pool.query(
                'UPDATE tv_series SET likes = likes + 1 WHERE id = ?',
                [req.params.id]
            );
        }

        const [series] = await pool.query(
            'SELECT likes, dislikes FROM tv_series WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            likes: series[0].likes,
            dislikes: series[0].dislikes
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   POST /api/tv-series/:id/dislike
// @desc    Dislike a TV series
// @access  Private
router.post('/:id/dislike', protect, async (req, res) => {
    try {
        // Check if user has already rated
        const [existingRating] = await pool.query(
            'SELECT * FROM user_ratings WHERE user_id = ? AND series_id = ?',
            [req.user.id, req.params.id]
        );

        if (existingRating[0]) {
            if (existingRating[0].rating === 'dislike') {
                return res.status(400).json({
                    success: false,
                    message: 'You have already disliked this series'
                });
            }

            // Update existing rating
            await pool.query(
                'UPDATE user_ratings SET rating = ? WHERE user_id = ? AND series_id = ?',
                ['dislike', req.user.id, req.params.id]
            );

            // Update series likes/dislikes
            await pool.query(
                'UPDATE tv_series SET likes = likes - 1, dislikes = dislikes + 1 WHERE id = ?',
                [req.params.id]
            );
        } else {
            // Create new rating
            await pool.query(
                'INSERT INTO user_ratings (user_id, series_id, rating) VALUES (?, ?, ?)',
                [req.user.id, req.params.id, 'dislike']
            );

            // Update series dislikes
            await pool.query(
                'UPDATE tv_series SET dislikes = dislikes + 1 WHERE id = ?',
                [req.params.id]
            );
        }

        const [series] = await pool.query(
            'SELECT likes, dislikes FROM tv_series WHERE id = ?',
            [req.params.id]
        );

        res.json({
            success: true,
            likes: series[0].likes,
            dislikes: series[0].dislikes
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

// @route   GET /api/tv-series/:id/comments
// @desc    Get all comments for a TV series
// @access  Public
router.get('/:id/comments', async (req, res) => {
    try {
        const [comments] = await pool.query(
            'SELECT c.*, u.name, u.profile_picture FROM comments c JOIN users u ON c.user_id = u.id WHERE c.series_id = ? ORDER BY c.created_at DESC',
            [req.params.id]
        );

        res.json({
            success: true,
            count: comments.length,
            comments
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            message: 'Server error'
        });
    }
});

module.exports = router; 