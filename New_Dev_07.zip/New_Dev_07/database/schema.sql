-- Create database
CREATE DATABASE IF NOT EXISTS streamix;
USE streamix;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    profile_picture VARCHAR(255) DEFAULT 'default-profile.png',
    subscription ENUM('free', 'premium', 'premium-plus') DEFAULT 'free',
    subscription_end_date DATETIME,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Movies table
CREATE TABLE IF NOT EXISTS movies (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    release_year YEAR NOT NULL,
    duration INT NOT NULL,
    poster_url VARCHAR(255) NOT NULL,
    trailer_url VARCHAR(255) NOT NULL,
    video_url VARCHAR(255) NOT NULL,
    director VARCHAR(255) NOT NULL,
    language VARCHAR(50) NOT NULL,
    rating DECIMAL(3,1) DEFAULT 0,
    views INT DEFAULT 0,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Movie genres table
CREATE TABLE IF NOT EXISTS movie_genres (
    id INT PRIMARY KEY AUTO_INCREMENT,
    movie_id INT NOT NULL,
    genre VARCHAR(50) NOT NULL,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

-- Movie cast table
CREATE TABLE IF NOT EXISTS movie_cast (
    id INT PRIMARY KEY AUTO_INCREMENT,
    movie_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(255) NOT NULL,
    image VARCHAR(255),
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

-- TV Series table
CREATE TABLE IF NOT EXISTS tv_series (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    start_year YEAR NOT NULL,
    end_year YEAR,
    poster_url VARCHAR(255) NOT NULL,
    trailer_url VARCHAR(255) NOT NULL,
    director VARCHAR(255) NOT NULL,
    language VARCHAR(50) NOT NULL,
    rating DECIMAL(3,1) DEFAULT 0,
    views INT DEFAULT 0,
    likes INT DEFAULT 0,
    dislikes INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- TV Series genres table
CREATE TABLE IF NOT EXISTS tv_series_genres (
    id INT PRIMARY KEY AUTO_INCREMENT,
    series_id INT NOT NULL,
    genre VARCHAR(50) NOT NULL,
    FOREIGN KEY (series_id) REFERENCES tv_series(id) ON DELETE CASCADE
);

-- TV Series cast table
CREATE TABLE IF NOT EXISTS tv_series_cast (
    id INT PRIMARY KEY AUTO_INCREMENT,
    series_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    role VARCHAR(255) NOT NULL,
    image VARCHAR(255),
    FOREIGN KEY (series_id) REFERENCES tv_series(id) ON DELETE CASCADE
);

-- Seasons table
CREATE TABLE IF NOT EXISTS seasons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    series_id INT NOT NULL,
    season_number INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (series_id) REFERENCES tv_series(id) ON DELETE CASCADE,
    UNIQUE KEY unique_season (series_id, season_number)
);

-- Episodes table
CREATE TABLE IF NOT EXISTS episodes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    season_id INT NOT NULL,
    episode_number INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    duration INT NOT NULL,
    video_url VARCHAR(255) NOT NULL,
    thumbnail_url VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (season_id) REFERENCES seasons(id) ON DELETE CASCADE,
    UNIQUE KEY unique_episode (season_id, episode_number)
);

-- User watchlist table
CREATE TABLE IF NOT EXISTS user_watchlist (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    movie_id INT,
    series_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (series_id) REFERENCES tv_series(id) ON DELETE CASCADE,
    CHECK (movie_id IS NOT NULL OR series_id IS NOT NULL)
);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    movie_id INT,
    series_id INT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (series_id) REFERENCES tv_series(id) ON DELETE CASCADE,
    CHECK (movie_id IS NOT NULL OR series_id IS NOT NULL)
);

-- User ratings table
CREATE TABLE IF NOT EXISTS user_ratings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    movie_id INT,
    series_id INT,
    rating ENUM('like', 'dislike') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
    FOREIGN KEY (series_id) REFERENCES tv_series(id) ON DELETE CASCADE,
    CHECK (movie_id IS NOT NULL OR series_id IS NOT NULL)
);

-- Create indexes for better performance
CREATE INDEX idx_movie_genres ON movie_genres(movie_id);
CREATE INDEX idx_movie_cast ON movie_cast(movie_id);
CREATE INDEX idx_tv_series_genres ON tv_series_genres(series_id);
CREATE INDEX idx_tv_series_cast ON tv_series_cast(series_id);
CREATE INDEX idx_episodes ON episodes(season_id);
CREATE INDEX idx_user_watchlist ON user_watchlist(user_id);
CREATE INDEX idx_comments ON comments(user_id, movie_id, series_id);
CREATE INDEX idx_user_ratings ON user_ratings(user_id, movie_id, series_id); 